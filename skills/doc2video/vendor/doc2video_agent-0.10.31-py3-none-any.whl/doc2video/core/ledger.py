"""Recording the chain as it happens — what ran, with what, and what came out.

Not a ledger in the accounting sense, whatever the filename says: it is the
record of one execution, ordered, with each step's outputs and the tools it
reached for.

Shaped after ``core/telemetry``: a recorder in a ContextVar, so a step deep in
the pipeline can name what it produced without every function between here and
there carrying a recorder argument. Jobs run one per thread and each thread
gets its own copy, so two renders cannot write into each other's account.

Append-only on disk, one JSON object per line. A render that dies halfway
leaves everything up to that point readable, which is exactly when someone
wants to read it — a ledger that only becomes valid at the end is no use for
the failures it exists to explain.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

from ..schemas.ledger import Artifact, ArtifactKind, EntryKind, LedgerEntry
from .logging import get_logger

log = get_logger(__name__)

LEDGER_FILE = "ledger.jsonl"

# One project's ledger is read whole by the UI; a long-lived project with many
# edits would otherwise grow without bound.
MAX_ENTRIES = 2000

_current: ContextVar[Recorder | None] = ContextVar("doc2video_ledger", default=None)

# What the step running right now has reached for. A ContextVar for the same
# reason the recorder is one: the tool that knows its own name is several
# frames below the step that will report it, and threading an argument through
# every one of them to carry a label is not worth it.
_tools: ContextVar[list[str] | None] = ContextVar("doc2video_ledger_tools", default=None)

# The stage a call belongs under, carried the same way and for the same reason.
_stage_seq: ContextVar[int] = ContextVar("doc2video_ledger_stage", default=0)

# What the code running right now is working on — a page, a scene. Carried
# rather than passed because the call that ends up being recorded is usually
# several frames below the loop that knows which scene it is: voicing a page
# is one call per speech unit, made inside the TTS tool, which has never heard
# of scenes. Without this the outputs cannot be put back beside the calls.
_covers: ContextVar[tuple[str, ...]] = ContextVar("doc2video_ledger_covers", default=())


class Recorder:
    """Writes one project's ledger. Safe to share across a run's threads."""

    def __init__(self, path: Path, run_id: str = "") -> None:
        self._path = path
        self._run_id = run_id
        self._lock = threading.Lock()
        self._seq = _last_seq(path)

    @property
    def path(self) -> Path:
        return self._path

    @contextmanager
    def run_scope(self, run_id: str) -> Iterator[None]:
        """Tag entries with a different run for the duration of a block.

        A chat turn is one account containing several runs: the agent decides,
        a render happens under its own run id, then it decides again. The
        entries stay in one numbered sequence; only their run tag changes.
        """
        previous = self._run_id
        self._run_id = run_id or previous
        try:
            yield
        finally:
            self._run_id = previous

    def _claim(self) -> int:
        """Take the next sequence number without writing anything yet."""
        with self._lock:
            self._seq += 1
            return self._seq

    def record(self, kind: EntryKind, name: str, **fields) -> LedgerEntry:
        return self.record_at(self._claim(), kind, name, **fields)

    def record_at(
        self,
        seq: int,
        kind: EntryKind,
        name: str,
        *,
        detail: str = "",
        status: str = "ok",
        duration_s: float = 0.0,
        artifacts: list[Artifact] | None = None,
        tools: list[str] | None = None,
        skill: str = "",
        parent: int = 0,
        covers: list[str] | None = None,
    ) -> LedgerEntry:
        """Write an entry under a number that may have been claimed earlier.

        A stage claims its number before its body runs, so the calls it makes
        can name it while it is still going; it is written when it ends.
        """
        entry = LedgerEntry(
            seq=seq,
            kind=kind,
            name=name,
            detail=detail,
            status=status,
            duration_s=duration_s,
            artifacts=artifacts or [],
            tools=tools or [],
            skill=skill,
            parent=parent,
            covers=covers or [],
            run_id=self._run_id,
        )
        self._append(entry)
        return entry

    @contextmanager
    def stage(self, name: str, detail: str = "", skill: str = "") -> Iterator[list[Artifact]]:
        """Time one step and record whatever it appends to the yielded list.

        The list is the step's way of saying what it made: it appends as it
        goes, and a failure still records everything produced before it, which
        is usually the most useful thing in the file.
        """
        artifacts: list[Artifact] = []
        started = time.monotonic()
        status = "ok"
        token = _tools.set([])
        # The number this stage will be written under. Claimed now rather than
        # at the end, because the calls inside it are written as they happen
        # and each one has to name the step it belongs to — a stage that only
        # gets its number after its body has run cannot be pointed at.
        seq_token = _stage_seq.set(self._claim())
        try:
            yield artifacts
        except Exception as exc:
            status = "failed"
            detail = detail or _why(exc)
            raise
        finally:
            used = _tools.get() or []
            seq = _stage_seq.get()
            _tools.reset(token)
            _stage_seq.reset(seq_token)
            self.record_at(
                seq,
                EntryKind.STAGE,
                name,
                detail=detail,
                status=status,
                duration_s=time.monotonic() - started,
                artifacts=artifacts,
                tools=used,
                skill=skill,
            )

    def _append(self, entry: LedgerEntry) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as handle:
                handle.write(entry.model_dump_json() + "\n")
        except OSError as exc:
            # An unwritable ledger must never take down the render it is
            # describing; losing the account is bad, losing the video is worse.
            log.debug("无法写入执行记录：%s", exc)


def _last_seq(path: Path) -> int:
    """Continue numbering across runs, so a project's chain reads in order."""
    try:
        with path.open("rb") as handle:
            return sum(1 for _ in handle)
    except OSError:
        return 0


# -- module-level access ---------------------------------------------------

def _returned(exc: BaseException) -> str:
    """What the tool actually sent back, when the error kept a piece of it."""
    extra = getattr(exc, "detail", None)
    if not isinstance(extra, dict):
        return ""
    return str(extra.get("snippet") or "").strip()


def _why(exc: BaseException) -> str:
    """Why it failed, in the space one line of the record has.

    `str(exc)` is the wrong thing to write down for the failures that actually
    happen here. A `CalledProcessError` stringifies to its command line — three
    hundred characters of node invocation, of which the first hundred and sixty
    were kept and the browser's actual complaint was not. Our own errors carry
    the reason in `detail`, and its tail is where a stack trace or a renderer's
    last words end up.
    """
    reason = str(getattr(exc, "message", "") or "") or str(exc)
    extra = getattr(exc, "detail", None)
    if isinstance(extra, dict):
        for key in ("stderr", "stdout", "reason", "error"):
            text = str(extra.get(key) or "").strip()
            if text:
                # The tail: a subprocess says what went wrong last.
                return f"{reason}｜…{text[-140:]}"
    return reason[:200]


@contextmanager
def recording(path: Path, run_id: str = "") -> Iterator[Recorder]:
    active = _current.get()
    if active is not None and active.path == path:
        # A chat turn records, and every render it causes records the same
        # project. A second recorder would start numbering from its own read of
        # the file and collide with the first, so nest instead of stacking.
        with active.run_scope(run_id):
            yield active
        return

    recorder = Recorder(path, run_id)
    token = _current.set(recorder)
    try:
        yield recorder
    finally:
        _current.reset(token)


def current() -> Recorder | None:
    """The active recorder, or None outside a run (tests, CLI inspection)."""
    return _current.get()


def note(name: str, detail: str = "", **kwargs) -> None:
    """Record something worth seeing, if anyone is recording."""
    recorder = _current.get()
    if recorder is not None:
        recorder.record(EntryKind.NOTE, name, detail=detail, **kwargs)


def decision(name: str, detail: str, artifacts: list[Artifact] | None = None) -> None:
    """Record why the agent did what it did next."""
    recorder = _current.get()
    if recorder is not None:
        recorder.record(EntryKind.DECISION, name, detail=detail, artifacts=artifacts)


def used(tool: str) -> None:
    """Name a tool the current step reached for. Deduplicated, order kept.

    Safe to call from anywhere, including outside a run: a tool should not have
    to know whether anyone is watching.
    """
    tools = _tools.get()
    if tools is not None and tool and tool not in tools:
        tools.append(tool)


def page_key(page: int) -> str:
    """How a page is named when a call claims it."""
    return f"page:{page}"


def scene_key(scene_id: str) -> str:
    return f"scene:{scene_id}"


@contextmanager
def scope(*keys: str) -> Iterator[None]:
    """Say what the code in this block is working on.

    Everything recorded inside claims these pages and scenes, however deep it
    is. Nests: a scene's scope holds while each of its speech units is written.
    """
    token = _covers.set(tuple(dict.fromkeys((*_covers.get(), *(k for k in keys if k)))))
    try:
        yield
    finally:
        _covers.reset(token)


@contextmanager
def call(
    tool: str,
    detail: str = "",
    artifacts: list[Artifact] | None = None,
    covers: list[str] | None = None,
) -> Iterator[list]:
    """Record one call — a model request, a page rasterised, a scene voiced.

    The stage entry answers "was it voiced"; this answers "which scene took
    eight seconds of it, and did that one fail". Both are wanted: a stage-only
    account of a thirty-scene render is one line for four minutes of work.

    Also names the tool on the enclosing stage, so `used` does not have to be
    called separately by anything that goes through here.

    Safe outside a run, like everything else in this module: a tool should not
    have to know whether anyone is watching.
    """
    used(tool)
    made: list[Artifact] = list(artifacts or [])
    recorder = _current.get()
    if recorder is None:
        yield made
        return

    started = time.monotonic()
    status = "ok"
    try:
        yield made
    except Exception as exc:
        status = "failed"
        why = _why(exc)
        detail = f"{detail}｜{why}" if detail else why
        # What came back, on the call that failed to make sense of it. The line
        # says 「不是合法 JSON 对象」 and that is the right summary, but it is not
        # enough to act on: a gateway rejecting `json_object` looks identical to
        # one that does not support it, and the reply that told them apart — a
        # Markdown outline where the JSON should have been — was thrown away.
        # Five failed calls said the same eleven words and nothing else, and the
        # answer had to be reproduced outside the app to be seen at all.
        said = _returned(exc)
        if said:
            made.append(text_artifact("返回内容", said))
        raise
    finally:
        recorder.record(
            EntryKind.CALL,
            tool,
            detail=detail,
            status=status,
            duration_s=time.monotonic() - started,
            artifacts=made,
            parent=_stage_seq.get(),
            covers=list(dict.fromkeys((*_covers.get(), *(covers or [])))),
        )


def degradation(name: str, detail: str) -> None:
    recorder = _current.get()
    if recorder is not None:
        recorder.record(EntryKind.DEGRADATION, name, detail=detail, status="skipped")


def read(path: Path, limit: int = MAX_ENTRIES) -> list[LedgerEntry]:
    """The account so far, oldest first."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []

    entries: list[LedgerEntry] = []
    for line in lines[-limit:]:
        if not line.strip():
            continue
        try:
            entries.append(LedgerEntry.model_validate_json(line))
        except ValueError:
            continue  # a truncated last line from a killed process
    return entries


# -- helpers for the steps that produce things -----------------------------
def file_artifact(
    label: str, path: str, kind: ArtifactKind, scene_id: str = "", page: int | None = None
) -> Artifact:
    return Artifact(label=label, kind=kind, path=path, scene_id=scene_id, page=page)


def text_artifact(
    label: str, text: str, scene_id: str = "", page: int | None = None
) -> Artifact:
    return Artifact(
        label=label, kind=ArtifactKind.TEXT, text=text, scene_id=scene_id, page=page
    )
