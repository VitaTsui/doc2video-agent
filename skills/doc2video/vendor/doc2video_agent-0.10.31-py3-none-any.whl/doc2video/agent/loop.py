"""The agent loop: a model deciding what to do next, over deterministic tools.

What this replaces is the honest problem with the old shape. The pipeline ran a
fixed list of eight stages and a regex tried to guess what "第 3 页太长了" meant;
the quality report was computed every run and read by nobody who could act on
it. That is a hand-rolled agent loop that cannot think — and it showed: the edit
path was a no-op for weeks because nothing downstream did anything with what
the regex parsed.

Here the model sees the deck and the script, and picks the next action. The
actions are exactly the operations that already existed; nothing here gives it
new powers over the machine. It cannot read files, run commands
or reach the network — it can write a script, rewrite one page, ask a question,
or stop.

**Decisions come back as JSON, not as native tool calls.** Five providers back
this, and one of them is a local CLI agent reached over a protocol that carries
a task string and nothing else. A tool-calling loop would work on four and
quietly exclude the one that needs no API key — so every provider answers the
same question in the same shape, and the loop stays one implementation.

Bounded on purpose: each render is minutes of CPU, so an agent free to iterate
is an agent that can spend an afternoon. It gets a small number of steps and a
smaller number of re-renders; running out is reported, not hidden.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from ..core import ledger
from ..core.logging import get_logger
from ..schemas import VideoProject
from ..schemas.session import Session, Speaker, Turn
from ..skills.base import load_prompt
from ..tools.llm import LLMTool, model_schema
from .session import SessionStore, compact

log = get_logger(__name__)

# One turn of conversation may cost several renders; this caps the afternoon.
MAX_STEPS = 6
# Re-renders are the expensive part — minutes each — so they are capped tighter
# than the step count.
MAX_RENDERS = 3


class Decision(BaseModel):
    """What to do next, and why.

    ``reason`` is not decoration: it is what the ledger shows the user when the
    agent decides to redo page 7, and the difference between an agent that
    looks capricious and one whose reasoning can be argued with.
    """

    action: Literal["write_script", "revise", "retune", "ask", "finish"]
    reason: str
    # write_script: page index (as a string) -> that page's narration. Scene
    # ids are accepted too, because that is what the prompt shows and a model
    # that reads its input will use them.
    narrations: dict[str, str] = Field(default_factory=dict)
    # revise: which scene, and what it should say instead.
    scene_id: str = ""
    narration: str = ""
    # retune: how it is spoken. Words untouched.
    voice: str = ""
    speech_rate: float = 0.0
    # ask / finish: what to say to the person.
    message: str = ""


class Outcome(BaseModel):
    """What one turn of the loop did."""

    reply: str
    steps: int = 0
    renders: int = 0
    stopped_because: str = ""


class AgentLoop:
    """Runs one turn of conversation to its conclusion.

    ``render`` is injected rather than imported so the loop can be tested
    without ffmpeg, and so the caller decides what "render" means — a first
    full pass, or one scene redone.
    """

    def __init__(
        self,
        project: VideoProject,
        llm: LLMTool,
        store: SessionStore,
        *,
        render_all,
        render_scene,
        revoice,
        reload,
        write_all=None,
    ) -> None:
        self.project = project
        self.llm = llm
        self.store = store
        self._render_all = render_all
        # Writing the deck is the narration skill's job, not this loop's.
        self._write_all = write_all or (lambda: render_all({}))
        self._render_scene = render_scene
        self._revoice = revoice
        self._reload = reload

    def run(self, message: str) -> Outcome:
        session = self.store.load(self.project.project_id)
        self._say(session, Speaker.USER, message)

        if not self.llm.available:
            # Without a model there is no loop; say so rather than silently
            # doing the one thing the old pipeline would have done.
            reply = "还没有配模型，我没法自己决定改什么。在下面选一个模型，或者直接把讲稿写给我。"
            self._say(session, Speaker.AGENT, reply)
            return Outcome(reply=reply, stopped_because="no_model")

        if compact(session, self.llm):
            self.store.rewrite(session)
            log.info("会话已压缩，折叠了较早的轮次")

        renders = 0
        for step in range(MAX_STEPS):
            decision = self._decide(session)
            ledger.decision(_ACTION_LABEL.get(decision.action, decision.action), decision.reason)
            self._say(session, Speaker.AGENT, decision.reason, action=decision.action)

            if decision.action == "finish":
                reply = decision.message or "好了。"
                self._say(session, Speaker.AGENT, reply)
                return Outcome(reply=reply, steps=step + 1, renders=renders)

            if decision.action == "ask":
                reply = decision.message or "我需要你再说明一下。"
                self._say(session, Speaker.AGENT, reply)
                return Outcome(
                    reply=reply, steps=step + 1, renders=renders, stopped_because="asked"
                )

            if renders >= MAX_RENDERS:
                reply = (
                    f"这一轮已经重做了 {renders} 次，先停下来听听你的意见——"
                    "再改下去我只是在猜。"
                )
                self._say(session, Speaker.AGENT, reply)
                return Outcome(
                    reply=reply, steps=step + 1, renders=renders, stopped_because="render_budget"
                )

            self._execute(decision, session)
            renders += 1
            self.project = self._reload()

        reply = f"我改了 {renders} 次还没定下来，先交给你看看。"
        self._say(session, Speaker.AGENT, reply)
        return Outcome(
            reply=reply, steps=MAX_STEPS, renders=renders, stopped_because="step_budget"
        )

    # -- the two halves ------------------------------------------------
    def _decide(self, session: Session) -> Decision:
        try:
            answer = self.llm.complete_json(
                self._prompt(session),
                schema=model_schema(Decision),
                system=_system(),
            )
            return Decision.model_validate(answer)
        except Exception as exc:  # noqa: BLE001 - a broken answer ends the turn, not the app
            # The cause, and a way out. What this said before — "我没想清楚下一步
            # 该做什么" — is a dead end dressed as modesty: nothing on screen
            # named the failure, and nothing said what the person could do
            # instead. They are usually one click from either fix.
            reason = str(exc)
            detail = getattr(exc, "detail", None)
            if detail:
                reason += "｜" + "；".join(f"{k}={str(v)[:200]}" for k, v in detail.items())
            log.warning("模型没有给出可用的决定：%s", reason)
            return Decision(
                action="finish",
                reason=f"模型没有给出可用的决定：{reason}",
                message=(
                    f"模型这一步没答上来：{reason[:300]}\n\n"
                    "两条路都能继续：在设置里换一个模型或补上 API Key；"
                    "或者直接把讲稿写给我——在上面每页的框里填字，留空的页我不动。"
                ),
            )

    def _execute(self, decision: Decision, session: Session) -> None:
        if decision.action == "write_script":
            pages = self._pages_of(decision.narrations)
            # Nothing supplied means "write it": the narration skill does that
            # page by page, against each page's character budget and under the
            # writing prompt. Measured on the same 30-page deck, that is 2135–
            # 2483 characters against the 1800 a model writes when asked for
            # thirty pages in one answer — and without the AI tics the writing
            # prompt exists to keep out.
            if pages:
                self._render_all(pages)
            else:
                self._write_all()
            self._say(
                session,
                Speaker.TOOL,
                f"按讲稿生成了 {len(pages)} 页" if pages else "逐页写了讲稿并生成了视频",
                action="write_script",
            )
        elif decision.action == "revise":
            self._render_scene(decision.scene_id, decision.narration)
            self._say(
                session,
                Speaker.TOOL,
                f"重做了 {decision.scene_id}",
                action="revise",
            )
        elif decision.action == "retune":
            self._revoice(decision.voice, decision.speech_rate)
            self._say(
                session,
                Speaker.TOOL,
                f"换成 {decision.voice or '默认音色'} 重新配音",
                action="retune",
            )

    def _pages_of(self, narrations: dict[str, str]) -> dict[int, str]:
        """Read the keys as pages, whatever the model keyed them by.

        The prompt lists the video as `scn_04（第 4 页…）` and the review names
        its findings by scene, so a model that reads its input keys by scene —
        and this used to end the turn with `invalid literal for int(): 'scn_04'`
        rather than doing what was asked. A key nobody can place is dropped and
        said out loud; it is one page, not the run.
        """
        by_scene = {scene.scene_id: scene.source_page for scene in self.project.scenes}
        pages: dict[int, str] = {}
        for key, text in narrations.items():
            if not text.strip():
                continue
            page = by_scene.get(key)
            if page is None:
                try:
                    page = int(str(key).strip())
                except (TypeError, ValueError):
                    log.warning("讲稿的键既不是页码也不是场景号，跳过：%r", key)
                    ledger.note("讲稿有一页对不上", detail=f"键 {key!r} 既不是页码也不是场景号")
                    continue
            pages[page] = text
        return pages

    # -- what the model sees -------------------------------------------
    def _prompt(self, session: Session) -> str:
        project = self.project
        lines = [
            f"# 当前工程：{project.document.title or '未命名'}",
            f"目标时长 {project.intent.duration} 秒，受众 {project.intent.audience}，"
            f"语气 {project.intent.tone}",
            "",
        ]

        if project.scenes:
            lines.append("# 现在的成片（逐页）")
            for scene in project.scenes:
                lines.append(
                    f"- {scene.scene_id}（第 {scene.source_page} 页，{scene.duration:.1f}s）："
                    f"{scene.narration[:120]}"
                )
        else:
            lines.append("# 还没有讲稿。下面是各页内容和字数预算")
            from ..skills import NarrationSkill
            from ..skills.base import SkillContext

            guide = {
                row["page"]: row
                for row in NarrationSkill(SkillContext.build(project, llm=self.llm)).guide()
            }
            for page in project.document.ordered_pages():
                budget = guide.get(page.index)
                lines.append(
                    f"- 第 {page.index} 页｜{page.page_type.value}｜{page.title or '无标题'}"
                    + (f"｜约 {budget['target_chars']} 字" if budget else "")
                )
                if page.key_points:
                    lines.append("    要点：" + "；".join(page.key_points))

        # No review block. The review stage is offline, and an old project's
        # stored report describes a film that no longer exists — handing the
        # decision model a stale score is worse than handing it nothing.

        lines += ["", "# 对话"]
        lines += [f"{turn.speaker.value}：{turn.text}" for turn in session.recent(12)]
        return "\n".join(lines)

    def _say(self, session: Session, speaker: Speaker, text: str, action: str = "") -> None:
        turn = Turn(speaker=speaker, text=text, action=action)
        session.turns.append(turn)
        self.store.append(turn)


_ACTION_LABEL = {
    "write_script": "决定写讲稿",
    "revise": "决定重做某一页",
    "retune": "决定换个声音重配",
    "ask": "决定先问清楚",
    "finish": "决定收工",
}

# The agent's own instructions live beside the other prompts, so the window can
# show them and someone can change them: it is the most consequential prompt in
# the product — it decides what happens after you say something — and it was
# the one that could not be read without opening the source.
def _system() -> str:
    return load_prompt("agent_loop")
