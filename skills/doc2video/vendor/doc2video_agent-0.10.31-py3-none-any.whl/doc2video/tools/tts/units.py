"""Speech units: how a page is broken up before it is spoken.

A page handed to a synthesiser in one piece comes back in one voice. The
engine picks an average pace somewhere in the first sentence and holds it for
forty seconds, and every pause it makes is the pause its punctuation table says
to make — the same length at every comma, the same length at every full stop.
That is most of what people hear as "machine reading".

So a page is spoken as several units, and the gaps between them are ours to
choose rather than the engine's. Each unit's duration is also measured as it
is written, so the sentence boundaries inside a scene are known exactly rather
than inferred from the pauses in one long clip.

A unit is where a beat is *decided*. It is not always where the audio is cut:
an engine that can be asked to hold — `[[slnc N]]` and its equivalents — is
asked, and speaks a whole sentence in one call, because a call is also one
complete intonation and a page cut into thirty of them sounds like thirty
utterances spliced together. Only an engine with nowhere to put the beat has
its clauses spoken separately. Either way the beats are the ones chosen here.

**The punctuation decides.** Two earlier rules did not. The first broke a unit
whenever nine seconds had gone by, which put the long pause wherever the
stopwatch happened to land — mid-sentence, mid-name. The second read the
sentence for turns and emphasis, which was better and still left the ordinary
sentences to a leftover length test (「上一句不足 2.2 秒就并进来」), so whether
two sentences ran together depended on an estimate of how long they took to
say. Both produced the same complaint: a pause inside a complete sentence, and
no pause where the writing plainly asked for one.

A written line already says where it breathes. 。 ends a thought; ； separates
two that belong together; ： leans forward into what follows; ，is a beat the
engine already takes inside the unit. Reading the mark is not an approximation
of the intent — it *is* the intent, written down by whoever wrote the line.

Turns and emphasis still lengthen a gap, because 「不过」 after a full stop is a
longer beat than the same full stop elsewhere. They never create one: a beat
only ever falls where the punctuation already put it.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from ...core import tuning

# How long to wait after each mark. Sized against what the engine does inside
# a unit, which is the rhythm the listener is already hearing: measured at
# 0.77s between two sentences `say` speaks in one breath. A full stop we chose
# sits level with that; the marks that hold a thought open are shorter, and
# the ones that end it harder are longer.
#
# Lengthened after listening: the film at 0.28 and 0.75 was heard as hurried
# even at a speaking rate barely above the engine's own. The gaps are half of
# what 「快」 means, and they are the half we control exactly.
#
# 、 and ，are here too, because 「the engine takes them at its own pace」 turned
# out to mean 「as long as a full stop」. Measured on a finished page: one
# sentence of 143 characters came back with commas of 0.33, 0.42, 0.43 and 0.33
# seconds against the 0.75 we had chosen for the sentence boundary — so the
# rhythm inside a sentence was nearly the rhythm between two. Cutting at every
# mark costs more clips and buys the only thing that makes this predictable:
# every silence in the film is one somebody chose.
PAUSE_COMMA = 0.32      # ，— a breath, not a stop
PAUSE_ENUM = 0.24       # 、— the shortest thing that is still a gap
# How long a run of 、-separated scraps may grow before it is spoken as one.
MERGE_UNTIL = 16
PAUSE_SENTENCE = 0.82   # 。 and a line that ends with no mark at all
PAUSE_EXCLAIM = 0.85    # ！？ — the sentence lands, then a beat
PAUSE_SEMICOLON = 0.55  # ；— two halves of one thought
PAUSE_COLON = 0.35      # ：— leans into what comes next
PAUSE_ELLIPSIS = 0.90   # …… — trailing off is the point
PAUSE_DASH = 0.50       # —— — an aside

# Before the sentence the writer marked as the point of the page.
PAUSE_EMPHASIS = 1.20
# Between one idea and the next, where the script turns.
PAUSE_TURN = 0.95

# Written with the mark last, so 「。」 does not match a line ending in 「……。」
# before the ellipsis rule gets to it.
MARKS: tuple[tuple[str, str], ...] = (
    ("……", "ellipsis"),
    ("，", "comma"),
    (",", "comma"),
    ("、", "enum"),
    ("...", "ellipsis"),
    ("——", "dash"),
    ("！", "exclaim"),
    ("？", "exclaim"),
    ("!", "exclaim"),
    ("?", "exclaim"),
    ("；", "semicolon"),
    (";", "semicolon"),
    ("：", "colon"),
    (":", "colon"),
    ("。", "sentence"),
    (".", "sentence"),
)

# The knob each mark reads. One per kind rather than one per character: 「?」 and
# 「？」 are the same pause to a listener.
KNOBS = {
    "comma": "voice.pause_comma",
    "enum": "voice.pause_enum",
    "sentence": "voice.pause_sentence",
    "exclaim": "voice.pause_exclaim",
    "semicolon": "voice.pause_semicolon",
    "colon": "voice.pause_colon",
    "ellipsis": "voice.pause_ellipsis",
    "dash": "voice.pause_dash",
}

# Closing quotes and brackets sit *after* the mark that matters: 「他说：『走。』」
# ends on a full stop even though its last character is a quote.
TRAILING = "\"'』」》）)】”’"

# The characters a clause may end on, and therefore where one is cut.
_MARK_CHARS = "，,、；;：:。.！!？?…—"
_CLAUSE = re.compile(rf"[^{_MARK_CHARS}]*[{_MARK_CHARS}]+|[^{_MARK_CHARS}]+")

# The words a script turns on. Not an exhaustive list of connectives — only
# the ones that begin a new movement rather than continue the current one.
TURNS = (
    "但是", "不过", "反过来", "另一方面", "接下来", "回到", "所以", "因此",
    "第一", "第二", "第三", "首先", "其次", "最后", "总的来说", "换句话说",
)


@dataclass
class Unit:
    """One clause, spoken on its own, and the beat that precedes it."""

    texts: list[str] = field(default_factory=list)
    pause_before: float = 0.0
    #: True when the gap before this piece is a breath inside a clause rather
    #: than a beat the punctuation asked for. An engine that speaks a whole
    #: sentence in one call phrases it itself and does not want ours.
    breath: bool = False
    #: Which of the caller's sentences this clause came out of. The captions and
    #: the camera are still cut by sentence; only the speaking is by clause.
    sentence: int = 0

    @property
    def text(self) -> str:
        return "".join(self.texts)


def mark_of(text: str) -> str:
    """Which kind of mark this piece ends on. Unmarked pieces read as a full stop."""
    stripped = text.rstrip().rstrip(TRAILING).rstrip()
    for mark, kind in MARKS:
        if stripped.endswith(mark):
            return kind
    return "sentence"


def pause_after(text: str) -> float:
    """The silence this piece's own punctuation asks for."""
    return tuning.value(KNOBS[mark_of(text)])


def clauses(sentence: str) -> list[str]:
    """Cut a sentence at its marks, keeping each mark with the piece it ends.

    A piece with nothing but a mark in it (「……」 on its own, a stray comma) is
    joined to the one before: it is punctuation, not something to say.
    """
    pieces: list[str] = []
    for piece in _CLAUSE.findall(sentence):
        if not piece.strip():
            continue
        if pieces and not any(ch not in _MARK_CHARS + TRAILING + " 　" for ch in piece):
            pieces[-1] += piece
        else:
            pieces.append(piece)
    return pieces or ([sentence] if sentence.strip() else [])


def _merge_short(pieces: list[str]) -> list[str]:
    """Put a run of tiny enumerated clauses back into one utterance.

    「建供应链、外贸、招投标三类情报，」 is three characters, two characters and
    eight — spoken as three clips, each paying the engine's own end-of-utterance
    lengthening, and the page came out a fifth slower than the same words in
    fewer pieces. Measured on a 30-page film: 224 characters in 37 clips, 190
    characters a minute against the 265 the same script ran at before.

    Only across 、, and only while the result stays short. The gaps this gives
    back to the engine are the shortest ones it takes; every mark that means
    something still gets the pause we chose.
    """
    merged: list[str] = []
    for piece in pieces:
        if (
            merged
            and mark_of(merged[-1]) == "enum"
            and len(merged[-1]) + len(piece) <= MERGE_UNTIL
        ):
            merged[-1] += piece
            continue
        merged.append(piece)
    return merged


def plan_units(
    sentences: list[str], *, emphasis: list[bool] | None = None, weight=None  # noqa: ARG001
) -> list[Unit]:
    """Cut `sentences` into clauses, and decide the beat before each.

    Every silence in the finished audio comes from here. A clause is spoken on
    its own, so the engine has no mark left inside it to pause at on its own
    schedule, and the gap that follows is the one its mark asks for — 、 shorter
    than ，, ，shorter than 。, and a turn or an emphasis longer still.

    `weight` is accepted and unused: it measured how long a sentence took to
    say, back when that decided where the units broke.
    """
    flags = list(emphasis or [])
    flags += [False] * (len(sentences) - len(flags))

    from .phrasing import BREATH, breaths

    units: list[Unit] = []
    previous, previous_mid = "", False
    for index, sentence in enumerate(sentences):
        # A clause with no punctuation in it is spoken in one unbroken push.
        # Long ones get the small breaths their own words allow — the seam a
        # person takes in 「它是全国石化化工领域唯一…」, which is not a pause and
        # is not nothing either.
        # `mid` marks a piece that is a breath inside a clause rather than the
        # end of one: the gap after it is a seam, not a beat.
        pieces: list[tuple[str, bool]] = []
        for clause in _merge_short(clauses(sentence.strip())):
            parts = breaths(clause)
            pieces += [(part, order < len(parts) - 1) for order, part in enumerate(parts)]

        for position, (piece, _mid) in enumerate(pieces):
            if not previous:
                gap = 0.0
            elif previous_mid:
                gap = BREATH
            else:
                gap = pause_after(previous)
            # The sentence's own beat — a turn, or the writer's mark — belongs
            # to the sentence, not to every clause inside it.
            own = _emphasis_of(piece, flags[index]) if position == 0 else 0.0
            units.append(
                Unit(
                    texts=[piece],
                    pause_before=max(gap, own),
                    sentence=index,
                    breath=previous_mid and own <= 0.0,
                )
            )
            previous, previous_mid = piece, _mid

    if units:
        # Nothing to pause before at the start; the scene's own lead silence
        # is already there.
        units[0].pause_before = 0.0
    return _even_out(units, sentences)


#: How much silence a page is allowed, per character it says.
#:
#: Every beat above is a fixed length, which makes a page's silence depend on
#: how its writer punctuated it rather than on how much it has to say. Measured
#: across one film: pages written in forty-character sentences spent 13% of
#: their time not talking, pages written in seventeen-character ones spent 25%,
#: and the speaking itself never changed pace — 5.13 characters a second on the
#: fast pages against 4.28 on the slow ones, which is what 「前面语速太快，后面
#: 语速又太慢」 sounds like from a seat in front of it.
#:
#: Thirty milliseconds a character is about a sixth of the time spent speaking:
#: enough for a real beat at every full stop on a page of long sentences, and a
#: ceiling on a page that stops every eight words.
PAUSE_PER_CHAR = 0.030

#: Never scale a beat below this. Below about this, a gap is not heard as a
#: pause; it is heard as a join, and a page of them runs on.
#:
#: It has to sit under the shortest beat there is (、 at 0.24) or it stops
#: being a floor and becomes a floor *and a ceiling*: set at 0.45 it raised
#: every comma from 0.32, and a page that was meant to be tightened came out
#: slower than before.
PAUSE_KEEP = 0.18

#: Below this, a page is not long enough for an average to mean anything.
#:
#: The allowance is a rate — so many milliseconds of silence per character —
#: and a rate applied to a section divider of eleven characters buys it a third
#: of a second for the whole page. Those pages are two sentences and a title
#: and the beats between them are the whole of their shape. The evening-out is
#: for pages that go on long enough to drift.
EVEN_OUT_FROM = 60


def _even_out(units: list[Unit], sentences: list[str]) -> list[Unit]:
    """Hold a page's silence to what its length can afford.

    A narrator reading eight short sentences does not take a full beat after
    each of them; they read them as one passage. This is that, arithmetically:
    the beats keep their proportions to each other — a 、 stays shorter than a
    ，, which stays shorter than a 。 — and all of them give way together until
    the page's total silence fits what it has to say.

    Only downward. A page with room to spare keeps the beats it was designed
    with; stretching them to fill the allowance would make a short page drawl.
    """
    said = sum(len(text.strip()) for text in sentences)
    total = sum(unit.pause_before for unit in units)
    allowed = said * PAUSE_PER_CHAR
    if said < EVEN_OUT_FROM or total <= allowed:
        return units
    scale = allowed / total
    for unit in units:
        if unit.pause_before <= 0:
            continue
        scaled = unit.pause_before * scale
        # The floor protects beats, not seams. A long clause with no
        # punctuation in it is cut at the breaths its own words allow, and a
        # breath is not a pause — it is the join between two halves of one
        # push. Held above the floor they add up faster than the beats do, and
        # a page made mostly of them could never come down to its allowance.
        unit.pause_before = scaled if unit.breath else max(PAUSE_KEEP, scaled)
    return units


def _ends_sentence(text: str) -> bool:
    """Whether this piece actually ends on a mark, rather than mid-clause.

    `mark_of` reads an unmarked piece as a full stop, which is right for a line
    that simply has no punctuation and wrong for a breath taken in the middle
    of one.
    """
    stripped = text.rstrip().rstrip(TRAILING).rstrip()
    return any(stripped.endswith(mark) for mark, _kind in MARKS)


def _emphasis_of(sentence: str, emphasised: bool) -> float:
    """The longer beat this sentence earns, or 0 to leave the mark's own."""
    if emphasised:
        return tuning.value("voice.pause_emphasis")
    head = sentence.lstrip("　 \t")[:4]
    if any(head.startswith(turn) for turn in TURNS):
        return tuning.value("voice.pause_turn")
    return 0.0
