"""Concrete TTS providers.

``macos_say`` gives real speech with zero setup on a Mac; ``silent`` guarantees
the pipeline produces a correctly-timed track anywhere. Cloud providers plug in
by subclassing TTSProvider — nothing above this file needs to change.
"""

from __future__ import annotations

import contextlib
import os
import re
import signal
import struct
import subprocess
import wave
from pathlib import Path

from ...core import ledger
from ...core.config import which
from ...core.errors import ToolFailed
from ...core.logging import get_logger
from .base import TTSProvider, audio_duration, estimate_duration
from .edge import EdgeProvider
from .kokoro import KokoroProvider
from .piper import PiperProvider

log = get_logger(__name__)

SAMPLE_RATE = 22050


class MacOSSayProvider(TTSProvider):
    """Uses the built-in macOS `say` binary, writing 16-bit PCM WAVE."""

    name = "macos_say"
    # It reads 「银行行长」 with two identical 行, so the words are rewritten
    # into characters that can only be read one way before they are sent.
    reads_polyphones = False
    # Measured end to end on a real page — synthesised in clauses and rejoined
    # with the pauses its punctuation asks for, which is how a page is spoken
    # now. 4.50 characters a second at rate 1.0; the older 4.75 was measured
    # before those pauses existed and budgets came out 5% long.
    chars_per_second = 4.50
    honours_phrase_boundary = True

    def available(self) -> bool:
        return which("say") is not None

    def voices(self) -> list[str]:
        listed = _say_voice_listing()
        names: list[str] = []
        for line in listed.splitlines():
            if "zh_CN" not in line:
                continue
            # The *whole* name, parentheses included. Most of these voices exist
            # in several languages under one first name, and `say -v Flo` picks
            # whichever Flo is the default — an English one, which writes a
            # 0.02-second file for a page of Chinese. Silent output, exit code
            # zero, and a scene with no narration in it. The listing's full
            # name is the only one that selects the Mandarin voice:
            #
            #     say -v "Flo (中文（中国大陆）)"  → 3.89s
            #     say -v Flo                      → 0.02s
            name = line.split("zh_CN")[0].strip()
            if name and name not in names:
                names.append(name)
        return names

    def phrase_boundary(self, text: str) -> str:
        """`say` ignores spaces in Chinese; `[[slnc N]]` it does obey.

        40 milliseconds is under the ear's threshold for a gap but is enough to
        make the parser start a new phrase there. Measured on 「国家人工智能应用
        中试基地」: the break moves off the middle of 中试 (1.79s, 0.27s long)
        and onto the boundary before it (1.68s, 0.20s), which is where a person
        reading the line aloud would take it.
        """
        return re.sub(r"[ \u3000]+", "[[slnc 40]]", text)

    def pause_markup(self, seconds: float) -> str:
        """A beat asked for inside one call, so the sentence stays one arc."""
        milliseconds = int(round(max(seconds, 0.0) * 1000))
        return f"[[slnc {milliseconds}]]" if milliseconds > 0 else ""

    def synthesize(self, text: str, out_path: Path, *, voice: str = "", rate: float = 1.0) -> float:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        # `say -r` is words per minute; 175 is roughly its natural pace.
        words_per_minute = int(175 * max(rate, 0.5))
        cmd = ["say", "-o", str(out_path), "--data-format=LEI16@22050", "-r", str(words_per_minute)]
        if voice:
            cmd += ["-v", voice]
        cmd += ["--", text]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=300)
        except subprocess.CalledProcessError as exc:
            raise ToolFailed(
                "macOS say 合成失败", detail={"stderr": exc.stderr.decode("utf-8", "ignore")[:400]}
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise ToolFailed("macOS say 合成超时") from exc

        duration = audio_duration(out_path)
        if duration is None:
            raise ToolFailed("无法读取合成音频时长", detail={"path": str(out_path)})
        return duration


class SilentProvider(TTSProvider):
    """Writes silence of the estimated duration.

    Not a toy: it keeps timeline, subtitles and director cues exercised and
    correctly timed on machines with no TTS available, so renders stay valid.
    """

    name = "silent"

    def available(self) -> bool:
        return True

    def synthesize(self, text: str, out_path: Path, *, voice: str = "", rate: float = 1.0) -> float:  # noqa: ARG002
        duration = estimate_duration(text, rate)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        frame_count = int(duration * SAMPLE_RATE)
        with wave.open(str(out_path), "wb") as handle:
            handle.setnchannels(1)
            handle.setsampwidth(2)
            handle.setframerate(SAMPLE_RATE)
            handle.writeframes(struct.pack("<h", 0) * frame_count)
        return duration


# What ``auto`` tries, in order. `say` first where it exists: it is instant,
# needs no model on disk, and is the reason macOS never noticed this project had
# no cross-platform voice. Piper is what every other platform gets — before it,
# a run off macOS produced a correctly timed, correctly subtitled, silent video.
# Best first — and "best" turned out to need an ear, not only numbers.
#
# Kokoro varies its pauses five times as much as `say` (0.66 against 0.13),
# which is the measurable half of sounding like a person rather than a
# punctuation table, and on that basis this list had it first. Listening
# settled it the other way for Mandarin narration: it carries an accent, and
# for explaining a deck an even, accentless delivery beats a livelier one that
# sounds foreign. The metric was necessary and not sufficient — it cannot hear
# an accent, and nothing here could have.
#
# So `say` leads where it exists. Kokoro sits ahead of Piper, which is where it
# earns its place: on Windows and Linux there is no `say`, and the choice is
# between a neural voice with an accent and the one shipped Piper model.
AUTO_ORDER: tuple[type[TTSProvider], ...] = (
    MacOSSayProvider,
    KokoroProvider,
    PiperProvider,
    SilentProvider,
)


#: The machine's `say -v ?` output, fetched once per process. None until a
#: listing has succeeded — failure is NOT cached, so a wedge now does not mean
#: an empty voice menu until restart.
_SAY_LISTING: str | None = None


def _say_voice_listing() -> str:
    """`say -v ?`, once, and wedge-proof.

    Two separate faults met here and took the desktop backend down. The
    listing was fetched fresh on every call, and `/health/voices` is polled by
    the window — so when macOS's speech daemon wedged (it does, after enough
    parallel synthesis), every poll spawned another 10-second probe. And the
    probe's own timeout was not the guarantee it looks like: on expiry
    `subprocess.run` kills the child and then waits for it again, and a child
    stuck in an uninterruptible wait on the wedged daemon survives SIGKILL —
    the wait blocks forever, one backend thread dies with it, and after a few
    hours of polling every endpoint that shares anything with this path hangs.
    「历史工程点开没东西了」 was this: the window's reopen flow awaits a request
    that will never answer.

    So: one probe per process, cached only on success; the child gets its own
    process group so the kill reaches whatever `say` spawned; and reaping is
    given one second, after which the zombie is abandoned — a leaked process
    entry is nothing, a leaked thread is the backend.
    """
    global _SAY_LISTING
    if _SAY_LISTING is not None:
        return _SAY_LISTING
    say = which("say")
    if say is None:
        return ""
    try:
        child = subprocess.Popen(
            [say, "-v", "?"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            start_new_session=True,
        )
    except OSError:
        return ""
    try:
        out, _ = child.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(OSError):
            os.killpg(child.pid, signal.SIGKILL)
        with contextlib.suppress(Exception):
            child.communicate(timeout=1)
        log.warning("say -v ? 超时——语音服务可能僵死，这次先返回空列表")
        return ""
    except Exception:  # noqa: BLE001 - a failed listing is an empty menu, not a crash
        return ""
    if child.returncode != 0:
        return ""
    _SAY_LISTING = out or ""
    return _SAY_LISTING


def resolve_provider(preference: str) -> TTSProvider:
    """Pick a provider by name, or the best available one for ``auto``."""
    registry: dict[str, type[TTSProvider]] = {
        MacOSSayProvider.name: MacOSSayProvider,
        KokoroProvider.name: KokoroProvider,
        EdgeProvider.name: EdgeProvider,
        PiperProvider.name: PiperProvider,
        SilentProvider.name: SilentProvider,
        "mock": SilentProvider,
    }

    if preference != "auto":
        provider_cls = registry.get(preference)
        if provider_cls is None:
            log.warning("未知的 TTS provider '%s'，回退到 auto", preference)
        else:
            provider = provider_cls()
            if provider.available():
                return provider
            reason = getattr(provider, "unavailable_reason", lambda: "")()
            log.warning(
                "TTS provider '%s' 当前不可用%s，回退到 auto",
                preference,
                f"（{reason}）" if reason else "",
            )

    refused: list[str] = []
    for provider_cls in AUTO_ORDER:
        provider = provider_cls()
        if provider.available():
            # Landing here is a mute film that passes every other check: the
            # silent provider writes a real clip of exactly the right length,
            # so nothing downstream can tell. Say it once, loudly, where the
            # run record keeps it — the alternative is a machine with no voice
            # quietly shipping a video nobody can hear.
            if isinstance(provider, SilentProvider):
                why = "；".join(refused) or "没有可用的引擎"
                log.warning("没有可用的配音引擎，本次是静音占位：%s", why)
                ledger.degradation(
                    "没有可用的配音引擎",
                    f"成片会是哑的（时间轴和字幕仍然正确）。{why}",
                )
            return provider
        reason = getattr(provider, "unavailable_reason", lambda: "")()
        name = provider_cls.name
        refused.append(f"{name}：{reason}" if reason else f"{name} 不可用")
    return SilentProvider()
